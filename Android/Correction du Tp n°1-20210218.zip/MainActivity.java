package com.example.projet2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

//import android.content.Context;
import android.app.ActionBar;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //LinearLayout layout = new LinearLayout(this);
        //ViewGroup.LayoutParams v = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
        //        ViewGroup.LayoutParams.MATCH_PARENT);
        //layout.setLayoutParams(v);
        //setContentView(layout);

        setContentView(R.layout.activity_main);

        Button monBouton = findViewById(R.id.monBouton);
        monBouton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                startActivity(new Intent(MainActivity.this, SecondActivity.class));
            }
        });

        Button bouton2 = findViewById(R.id.boutonSiteWeb);
        bouton2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent t = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.esaip.org/"));
                startActivity(t);
            }
        });

        Button bouton3 = findViewById(R.id.boutonAvecRetour);
        bouton3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent t = new Intent(MainActivity.this, ThirdActivity.class);
                startActivityForResult(t,13);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==13){
            String s = data.getStringExtra(new String("retour"));
            Toast.makeText(getApplicationContext(), s, 5).show();
        } //else {
        //    Toast.makeText(getApplicationContext(), "et zut", 5).show();
        //}

    }
}