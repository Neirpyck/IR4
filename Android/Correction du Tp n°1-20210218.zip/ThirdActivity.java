package com.example.projet2;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ThirdActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third_activity);

        Button bouton4 = findViewById(R.id.boutonRetour);
        bouton4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                TextView text = findViewById(R.id.textView2);
                Intent t = new Intent();
                t.putExtra(new String(""), text.getText());
                setResult(Activity.RESULT_OK,t);
                finish();
            }
        });
    }


}
