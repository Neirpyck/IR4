package com.example.projet4;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

public class MainActivity extends ListActivity {

    private final String[] desserts = new String[] {
            "crème brulée", "crumble aux framboises",
            "panna cotta", "tarte aux pommes"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        super.setListAdapter(new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, desserts));

    }
}